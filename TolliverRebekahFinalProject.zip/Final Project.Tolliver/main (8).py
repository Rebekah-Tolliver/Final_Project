#Rebekah Tolliver
#SDEV140
#27 February 2023
#Sandwicher creates an easy to use ordering system for a sandwich shop. This gives the user a sandwich through the meat they choose and whether they will have cheese on there sandwich or not.
 
from breezypythongui import EasyFrame
from tkinter import PhotoImage

#creates a  primary window
class Sandwicher(EasyFrame):
  def __init__(self):
    #Frame Setup
    EasyFrame.__init__(self, title= "Sandwicher")
    self.setResizable(True);
    self.setSize(600,450)

    #Top of GUI Logo Photo
    ImageLabel_1 = self.addLabel(text = "", row=0, column=1, sticky = "NSEW" )
    self.Image_1 = PhotoImage(file = "Sandwicher.png")
    ImageLabel_1["image"] = self.Image_1

    #Input and Label 1: Sandwich Meat
    MeatLabel = self.addLabel(text = "Sandwich Meat Selection:", row = 1, column = 0, sticky = "NSEW")
    self.MeatInput = self.addTextField(text = "none", row = 1, column = 1, width = 10, sticky = "NSEW")#text field to input the meat the user wants

    #Input and Label 2: Cheese or No Cheese
    CheeseLabel = self.addLabel(text = "Yes or No for Cheese:", row = 2, column = 0, sticky = "NSEW")
    self.CheeseInput = self.addTextField(text = "none", row = 2, column = 1, width = 10, sticky = "NSEW")#text field to input whether the user want s cheese or not on their sandwich

    #Sandwich Blank Image
    ImageLabel_2 = self.addLabel(text = "", row = 3, column = 1, sticky = "NSEW") #This displays where the future sandwich image will appear
    self.Image_2 = PhotoImage(file = "Blank.png")
    ImageLabel_2["image"] = self.Image_2

    #Sandwich Label
    self.SandwichLabel = self.addLabel(text = "Sandwich Name", row = 4, column = 1, sticky = "NSEW")

    #Buttons
    Process = self.addButton(text = "Process", row = 5, column = 0, command = self.SandProcess)
    Reset = self.addButton(text = "Reset", row = 5, column = 1, command = self.ResetApp)
    Exit = self.addButton(text = "Exit", row = 5, column = 2, command = self.QuitApp)

  #functions
  def GetMeat(self, UserMeat):
    if UserMeat == "Ham" or UserMeat == "Turkey" or UserMeat == "Roastbeef" or UserMeat == "Chicken":
      if UserMeat == "Ham":
        return "H"
      elif UserMeat == "Turkey":
        return "T"
      elif UserMeat == "Roastbeef":
        return "R"
      elif UserMeat == "Chicken":
        return "C"
      else:
        self.messageBox(title = "Error", message = "Sandwich Meat Input must be a string saying Ham, Turkey, Roastbeef, or Chicken.")

  #Checks user input to create 1st half of dictionary key
  def GetCheese(self, UserCheese):
    if UserCheese == "Yes" or UserCheese == "No":
      if UserCheese == "Yes":
        return "C"
      else:
        return "N"

    #Combine 1st and 2nd half of key to index dictionary and Obtain Sandwich
  def GetSandwich(self,first,second):
    #Dictionary that holds sandwiches with or without cheese as keys.
    DictionaryOfSandwiches = {"HN":"HamSandwich","HC":"HamCheeseSub","TN":"TurkeySandwich","TC":"TurkeyCheeseSub","RN":"RoastBeefNoCheese","RC":"RoastBeefSandwich","CN":"ChickenSandwich","CC":"ChickenCheeseSub",}
    key = first+second
    SandName = DictionaryOfSandwiches[key]
    return SandName

  #Button Functions that process which sandwich to give
  def SandProcess(self):
    #Input Validation for Meat Input
    try:
      StringInput = self.MeatInput.getText()
    except ValueError:
      self.messageBox(title="Error", message="Sandwich Meat Input must be a string saying Ham, Turkey, Roastbeef, or Chicken.")

      #Input Validation for Cheese Input
    try:
      StringInput_2 = self.CheeseInput.getText()
    except ValueError:
      self.messageBox(title="Error", message="Sandwich Cheese Input must be a Yes or No.")

    #This gives displays what sandwich the user inputs
    Meat = self.GetMeat(StringInput)
    Cheese = self.GetCheese(StringInput_2)
    BuiltKey = self.GetSandwich(Meat, Cheese) #Gives the sandwich from the input

    #Dictionary output used to update the GUI
    self.SandwichLabel["text"] = (BuiltKey)
    self.Image_2["file"] = (BuiltKey + ".png")

  def ResetApp(self):
    self.SandwichLabel["text"] = ("Sandwich Name")
    self.Image_2["file"] = ("Blank.png")

  #Quit the App
  def QuitApp(self):
    exit()

#Pops window up
def main():
  Sandwicher().mainloop()

if __name__ == "__main__":
  main()